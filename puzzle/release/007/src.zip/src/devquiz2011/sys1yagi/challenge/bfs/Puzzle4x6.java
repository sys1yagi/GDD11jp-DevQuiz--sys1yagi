package devquiz2011.sys1yagi.challenge.bfs;

public class Puzzle4x6 extends Puzzle3x3 {
//
//	@Override
//	public int getLimitDepth(){
//		return 150;
//	}
	
//	@Override
//	public String start() {
//		return null;
//	}
//	@Override
//	public int getMaxCount() {
//		return 40000;
//	}
}
