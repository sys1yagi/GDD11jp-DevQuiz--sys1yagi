package devquiz2011.sys1yagi.challenge.bfs;

public class Queues {

}
