package devquiz2011.sys1yagi.challenge.bfs;

public class Puzzle5x5 extends Puzzle3x3 {

//	@Override
//	public int getLimitDepth(){
//		return 150;
//	}
//	@Override
//	public int getMaxCount() {
//		return 40000;
//	}
	
//	@Override
//	public String start() {
//		return null;
//	}
}
