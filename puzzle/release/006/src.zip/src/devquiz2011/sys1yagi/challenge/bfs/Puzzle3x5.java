package devquiz2011.sys1yagi.challenge.bfs;

public class Puzzle3x5 extends Puzzle3x3 {
//	@Override
//	public int getLimitDepth(){
//		return 170;
//	}
//	
//	@Override
//	public int getMaxCount() {
//		return 30000;
//	}
//	@Override
//	public String start() {
//		return null;
//	}
}
