package devquiz2011.sys1yagi.challenge.bfs;

public class Puzzle3x4 extends Puzzle3x3 {
//	@Override
//	public int getLimitDepth() {
//		return 90;
//	}

	
//	@Override
//	public String start() {
//		return null;
//	}
}
